interface UsuarioGadgets {

    fun equiparGadget(gadget: String): String

    fun usarGadget(): String
}