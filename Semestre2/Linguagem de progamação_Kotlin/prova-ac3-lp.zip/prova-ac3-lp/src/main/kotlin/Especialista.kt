interface Especialista {

    fun especialidade(): String

    fun tratarPaciente(): String

}