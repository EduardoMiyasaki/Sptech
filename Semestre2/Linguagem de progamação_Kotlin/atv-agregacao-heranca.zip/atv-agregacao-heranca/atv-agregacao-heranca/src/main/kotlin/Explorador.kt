class Explorador : Aventureiro() {

    var nivelExperiencia: Int = 0
        private set

    private val missoes = mutableListOf<Missao>()

    fun inscreverEmMissao(missao: Missao) {
        missoes.add(missao)
    }

    fun listarMissoes(): List<Missao> {
        return missoes
    }

    fun abandonarMissao(nomeMissao: String) {
        missoes.removeIf { it.nome == nomeMissao }
    }

    fun ganharExperiencia(pontos: Int) {
        this.nivelExperiencia += pontos;
    }

    fun dificuldadeMediaMissoes(): Int {

        val listaMissoes = listarMissoes()

        var somaDificuldade = 0

        if (listaMissoes.isEmpty()) {
            return 0
        }

        for (i in 0..listaMissoes.size) {
            somaDificuldade += listaMissoes[i].nivelDificuldade
        }

        val media = somaDificuldade / listaMissoes.size
        return media
    }
}